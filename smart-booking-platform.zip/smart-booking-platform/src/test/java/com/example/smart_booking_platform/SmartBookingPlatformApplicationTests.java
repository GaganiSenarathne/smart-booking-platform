package com.example.smart_booking_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartBookingPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
